//: A UIKit based Playground for presenting user interface


//this code is an attemp for open and close principle
//and also follows single responsibility principle
  
import UIKit
import PlaygroundSupport

enum  PColor {
  case green;
  case red;
  case yellow;
}


enum PSize {
  case small;
  case large;
  case medium
}


enum Price {
  case cheap;
  case expensive;
}



class Product<Feature1, Feature2, Feature3> {
 
  var feature: Feature1
  var feature2: Feature2
  var feature3: Feature3
  
  init(feature1: Feature1, feature2: Feature2, feature3: Feature3) {
    self.feature = feature1
    self.feature2 = feature2
    self.feature3 = feature3
  }
  
  
  //geters
  func getFeatures() -> (Feature1, Feature2, Feature3) {
    return (feature, feature2, feature3)
  }

}



//now you want to filter the feture how will you do it ?

//so lets asume that for each Feature there would be a filter?

protocol FeatureSpecification {
  associatedtype T;
  func isSatified(_ item: T) -> Bool
}


//now we create a protocol for the filter
protocol FilterItems {
  associatedtype T;
  func filterOnFeature<featureSpec: FeatureSpecification>(items: [T], spec: featureSpec) -> [T] where featureSpec.T == T;
}



class Color: FeatureSpecification {
  typealias T = Product;
  var color: PColor
  
  init(color: PColor) {
    self.color = color;
  }
  
  func isSatified(_ item: Product<PColor, PSize, Price>) -> Bool{
    guard let itemSize = item.feature as? PColor, itemSize == self.color else {
      return false
    }
    return true
  }
  
}



class SizeSpec: FeatureSpecification {
  
  
  typealias T = Product;
  
  var pSize: PSize;
  
  init(prSize: PSize) {
    self.pSize = prSize;
  }
  
  func isSatified(_ item: Product<PColor, PSize, Price>) -> Bool {
    guard item.feature2 == self.pSize else {
      return false
    }
    return true
  }
}




//prepare the filter class
class Filter: FilterItems {
  
  typealias T = Product;
  
  func filterOnFeature<featureSpec>(items: [Product<PColor, PSize, Price>], spec: featureSpec) -> [T<PColor, PSize, Price>] where featureSpec : FeatureSpecification, T<PColor, PSize, Price> == featureSpec.T {
    var filteredItems: [Product<PColor, PSize, Price>] = []
    
    for item in items {
      if spec.isSatified(item) {
        filteredItems.append(item)
      }
    }
    return filteredItems;
  }
  
}



let house = Product(feature1: PColor.green, feature2: PSize.large, feature3: Price.expensive)


let apples = Product(feature1: PColor.red, feature2: PSize.small, feature3: Price.cheap)

var arry = [house, apples];

let filter = Filter()
let colorSpecification = Color(color: .red)
let items  = filter.filterOnFeature(items: arry, spec: colorSpecification)
print(items[0].getFeatures())


